﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralSample.Core.Interfaces
{
    //Input set for the neurons
    public interface IInput<T>
    {
    }
}
