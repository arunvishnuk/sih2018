﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralSample.Core.Interfaces
{
    //The actual neurons
    public interface INeuron<T>
    {
        public List<IOutput<T>> GetOutput(List<IInput<T>> inList);


        public void Train(List<ITrainingSet<T>> trainingSet);
    }
}
