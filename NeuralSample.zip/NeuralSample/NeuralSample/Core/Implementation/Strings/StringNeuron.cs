﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using NeuralSample.Core.Interfaces;

namespace NeuralSample.Core.Implementation.Strings
{
    public class StringNeuron:INeuron<StringData>
    {

        public List<StringOutput> GetOutput(List<StringInput> inList)
        {
            throw new NotImplementedException();
        }

        public void Train(List<StringSet> trainingSet)
        {
            throw new NotImplementedException();
        }
    }
}
