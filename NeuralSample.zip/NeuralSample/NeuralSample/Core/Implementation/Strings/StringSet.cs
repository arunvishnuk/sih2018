﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using NeuralSample.Core.Interfaces;

namespace NeuralSample.Core.Implementation.Strings
{
    public class StringSet:ITrainingSet<string>
    {
    }
}
