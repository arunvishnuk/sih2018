﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tribal_FRA_Awareness___Desktop
{
    /// <summary>
    /// Interaction logic for Welcome.xaml
    /// </summary>
    public partial class Home : Page
    {
        public Home()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            UserLogin login = new UserLogin();
            this.NavigationService.Navigate(login);
            if (this.ShowsNavigationUI != true)
            {
                this.ShowsNavigationUI = true;
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            TaskForceLogin tf = new TaskForceLogin();
            this.NavigationService.Navigate(tf);
            if (this.ShowsNavigationUI != true)
            {
                this.ShowsNavigationUI = true;
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            OfficerLogin of = new OfficerLogin();
            this.NavigationService.Navigate(of);
            if (this.ShowsNavigationUI != true)
            {
                this.ShowsNavigationUI = true;
            }
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            SignUp sg = new SignUp();
            this.NavigationService.Navigate(sg);
        }
    }
}
