﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tribal_FRA_Awareness___Desktop
{
    /// <summary>
    /// Interaction logic for UserLogin.xaml
    /// </summary>
    public partial class UserLogin : Page
    {
        public UserLogin()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            if (!string.IsNullOrEmpty(unameText.Text) && !string.IsNullOrEmpty(userPwd.Password))
            {
                int count = DBConnectivity.GetCount(unameText.Text, userPwd.Password);
                if (count == 1)
                {
                    Dashboard d = new Dashboard(new User(unameText.Text,UserType.User));
                    this.NavigationService.Navigate(d);
                    this.ShowsNavigationUI = false;
                }
                else
                {
                    MessageBox.Show("Username or Password Not Found.");
                }
            }
            else
            {
                MessageBox.Show("Incorrect UserName or Password","Error",MessageBoxButton.OK,MessageBoxImage.Exclamation);
            }
        }

        private void unameText_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
