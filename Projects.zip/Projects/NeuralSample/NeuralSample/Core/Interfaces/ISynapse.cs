﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Speech;



namespace NeuralSample.Core.Interfaces
{
    //The synapse(connection for the neurons)
    public interface ISynapse<T>
    {

        public INetwork<T> CreateNet(List<INeuron<T>> neurons);
        

    }
}
