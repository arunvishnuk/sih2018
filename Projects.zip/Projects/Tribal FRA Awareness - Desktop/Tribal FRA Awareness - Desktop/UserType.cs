﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tribal_FRA_Awareness___Desktop
{
    public enum UserType
    {
        User,
        TaskForce,
        Officer
    }
}
