﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tribal_FRA_Awareness___Desktop
{
    /// <summary>
    /// Interaction logic for SignUp.xaml
    /// </summary>
    public partial class SignUp : Page
    {
        public SignUp()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if(!string.IsNullOrEmpty(fName.Text) && !string.IsNullOrEmpty(lName.Text) && !string.IsNullOrEmpty(email.Text) && !string.IsNullOrEmpty(passwrd.Password) && !string.IsNullOrEmpty(cPasswrd.Password))
            {
                if(string.Equals(passwrd.Password,cPasswrd.Password))
                {
                    char gender='M';
                    if (male.IsEnabled)
                        gender = 'M';
                    else if (female.IsEnabled)
                        gender = 'F';
                    else
                    { }
                    int res = DBConnectivity.Insert(userName.Text, passwrd.Password, fName.Text, lName.Text, email.Text, gender);
                    if (res == 0)
                    {
                        MessageBox.Show("Sign Up Successful. Please Login now.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                        this.NavigationService.GoBack();
                    }
                    else
                    {
                        MessageBox.Show("Error Signing Up.");
                    }
                }
                else
                {
                    MessageBox.Show("Passwords do not Match. Please enter correct password in Confirmation field.","Password Mismatch",MessageBoxButton.OK,MessageBoxImage.Exclamation);
                }
            }
            else
            {
                MessageBox.Show("Please fill in Empty Fields.","Form not filled",MessageBoxButton.OK,MessageBoxImage.Exclamation);
            }
        }
    }
}
