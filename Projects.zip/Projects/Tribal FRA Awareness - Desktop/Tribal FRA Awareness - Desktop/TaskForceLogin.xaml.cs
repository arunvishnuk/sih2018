﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tribal_FRA_Awareness___Desktop
{
    /// <summary>
    /// Interaction logic for TaskForceLogin.xaml
    /// </summary>
    public partial class TaskForceLogin : Page
    {
        public TaskForceLogin()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(tfUname.Text) && !string.IsNullOrEmpty(tfPwd.Password))
            {
                int c = DBConnectivity.GetCount(tfUname.Text, tfPwd.Password);
                if (c == 1)
                {
                    Dashboard d = new Dashboard(new User(tfUname.Text,UserType.TaskForce));
                    this.NavigationService.Navigate(d);
                    this.ShowsNavigationUI = false;
                }
                else
                {
                    MessageBox.Show("Incorrect password or UserId");
                }
            }
            else
            {
                MessageBox.Show("Incorrect Username or Password", "Error", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
        }
    }
}
