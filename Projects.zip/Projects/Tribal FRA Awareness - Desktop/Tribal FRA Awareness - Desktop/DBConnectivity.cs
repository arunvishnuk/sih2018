﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql;
using MySql.Data.MySqlClient;
using System.Data;
 

namespace Tribal_FRA_Awareness___Desktop
{
    static class DBConnectivity
    {
        static MySqlConnection connection;
        //static MySqlDataAdapter adapter;
        public static int GetCount(string uName, string pwd)
        {
            String connString = "server=localhost;uid=root;pwd=root;database=Tribalparent;";
            connection = new MySqlConnection(connString);
            try
            {
                if (connection.State != ConnectionState.Open)
                    connection.Open();
                string query = "SELECT COUNT(1) FROM TRIBALUSERS WHERE UserId=@Username AND Password=@Password";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.CommandType = CommandType.Text;
                command.Parameters.AddWithValue("@Username", uName);
                command.Parameters.AddWithValue("@Password", pwd);
                int count = Convert.ToInt32(command.ExecuteScalar());
                return count;
            }
            catch(Exception ex)
            {

            }
            return -1;
        }

        public static void Update(string Userid, string newemail, string newpwd)
        {
            String connString = "server=localhost;uid=root;pwd=root;database=Tribalparent;";
            connection = new MySqlConnection(connString);
            try
            {
                if (connection.State != ConnectionState.Open)
                    connection.Open();
                string query = "UPDATE Tribalusers SET EmailId=@email,Password=@password where UserId=@uid";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.CommandType = CommandType.Text;
                command.Parameters.AddWithValue("@uid", Userid);
                command.Parameters.AddWithValue("@password", newpwd);
                command.Parameters.AddWithValue("@email", newemail);

                try
                {
                    command.ExecuteScalar();
                }
                catch (Exception e)
                {

                }
            }
            catch(Exception e)
            {

            }

        }
    


        public static int Insert(string uName,string pwd,string fname,string lname,string email,char gender)
        { 
           String connString = "server=localhost;uid=root;pwd=root;database=Tribalparent;";
            connection = new MySqlConnection(connString);
            try
            {
                if (connection.State != ConnectionState.Open)
                    connection.Open();
                string query = "INSERT INTO Tribalusers VALUES(@username,@name,@gender,@email,@password)";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.CommandType = CommandType.Text;
                command.Parameters.AddWithValue("@username", uName);
                command.Parameters.AddWithValue("@password", pwd);
                command.Parameters.AddWithValue("@email", email);
                command.Parameters.AddWithValue("@name", fname + lname);
                command.Parameters.AddWithValue("@gender", gender);
                try
                {
                    command.ExecuteScalar();
                }
                catch(Exception e)
                {
                    return -1;
                }
                
          }
            catch(Exception ex)
            {
                
            }
            return 0;

    }

        public static string getemail(string p)
        {
            String connString = "server=localhost;uid=root;pwd=root;database=Tribalparent;";
            connection = new MySqlConnection(connString);
            try
            {
                if (connection.State != ConnectionState.Open)
                    connection.Open();
                string query = "SELECT EmailId FROM Tribalusers WHERE UserId=@uid";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.CommandType = CommandType.Text;
                command.Parameters.AddWithValue("@uid",p);
                
                try
                {
                    return command.ExecuteScalar().ToString();
                }
                catch (Exception e)
                {
                   
                }

            }
            catch (Exception ex)
            {

            }
            return string.Empty;
        }

        public static string getgender(string p)
        {
            String connString = "server=localhost;uid=root;pwd=root;database=Tribalparent;";
            connection = new MySqlConnection(connString);
            try
            {
                if (connection.State != ConnectionState.Open)
                    connection.Open();
                string query = "SELECT Gender FROM Tribalusers WHERE UserId=@uid";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.CommandType = CommandType.Text;
                command.Parameters.AddWithValue("@uid", p);

                try
                {
                    return command.ExecuteScalar().ToString();
                }
                catch (Exception e)
                {

                }

            }
            catch (Exception ex)
            {

            }
            return string.Empty;
        }

        public static string getname(string p)
        {
            String connString = "server=localhost;uid=root;pwd=root;database=Tribalparent;";
            connection = new MySqlConnection(connString);
            try
            {
                if (connection.State != ConnectionState.Open)
                    connection.Open();
                string query = "SELECT Name FROM Tribalusers WHERE UserId=@uid";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.CommandType = CommandType.Text;
                command.Parameters.AddWithValue("@uid",p);
                
                try
                {
                    return command.ExecuteScalar().ToString();
                }
                catch (Exception e)
                {
                   
                }

            }
            catch (Exception ex)
            {

            }
            return string.Empty;
            }
    }

}
