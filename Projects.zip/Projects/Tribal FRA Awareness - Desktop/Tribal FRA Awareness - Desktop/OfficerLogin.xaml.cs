﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tribal_FRA_Awareness___Desktop
{
    /// <summary>
    /// Interaction logic for OfficerLogin.xaml
    /// </summary>
    public partial class OfficerLogin : Page
    {
        public OfficerLogin()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(offName.Text) && !string.IsNullOrEmpty(offPass.Password))
            {
                int count = DBConnectivity.GetCount(offName.Text, offPass.Password);
                if (count == 1)
                {
                    Dashboard d = new Dashboard(new User(offName.Text,UserType.Officer));
                    this.NavigationService.Navigate(d);
                    this.ShowsNavigationUI = false;
                }
                else { MessageBox.Show("Incorrect userid or password");
                }
            }
            else
            {
                MessageBox.Show("Incorrect Username or Password", "Error", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
        }
    }
}
