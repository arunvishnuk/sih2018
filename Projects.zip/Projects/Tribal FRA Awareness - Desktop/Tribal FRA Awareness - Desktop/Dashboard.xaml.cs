﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;
using System.IO;
using System.Diagnostics;
using iTextSharp.text.pdf.parser;
using iTextSharp.text.pdf;

namespace Tribal_FRA_Awareness___Desktop
{
    /// <summary>
    /// Interaction logic for Dashboard.xaml
    /// </summary>
    public partial class Dashboard : Page
    {
        public User user { get; private set; }
        public Dashboard()
        {
            InitializeComponent();
            this.Loaded += Dashboard_Loaded;
        }

        void Dashboard_Loaded(object sender, RoutedEventArgs e)
        {
            this.id.Content = user.UserName;
            this.name.Content = DBConnectivity.getname(user.UserName);
            this.gender.Content = DBConnectivity.getgender(user.UserName);
            this.email.Content = DBConnectivity.getemail(user.UserName);
        }

        public Dashboard(User user):this()
        {
            this.user = user;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new EditProfile(user));
        }

        private void Hyperlink_Click_1(object sender, RoutedEventArgs e)
        {
            this.NavigationService.RemoveBackEntry();
            this.NavigationService.Navigate(new Home());
        }

        private void Hyperlink_Click_2(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            //wc.DownloadProgressChanged+=(s,ex)=>
            //{
            //    progress.Value = ex.ProgressPercentage;
            //};
            StringBuilder sb = new StringBuilder();
            wc.DownloadFile("https://tribal.nic.in/writereaddata/Schemes/3-1MJGuidelines.pdf", "one.pdf");
            try 
            {
                PdfReader reader = new PdfReader("one.pdf");
                string text = string.Empty;
                for (int page = 1; page <= reader.NumberOfPages; page++)
                {
                    text += PdfTextExtractor.GetTextFromPage(reader, page);
                }
                reader.Close();
                FileStream fs = new FileStream("out.txt", FileMode.CreateNew);
                StreamWriter ws = new StreamWriter(fs);
                ws.Write(text);

                fs.Dispose();
                ws.Dispose();
                
                //MessageBox.Show(text);
            }
            catch (Exception ex) 
            {
                Console.WriteLine(ex.Message);
            }
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Program Files\Adobe\Reader 11.0\Reader\AcroRd32.exe";
            p.StartInfo.Arguments = @"one.pdf";
            p.Start();

        }
        private void Hyperlink_Click_3(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.DownloadFile("https://tribal.nic.in/writereaddata/Schemes/3-B-MJ-MSPtoMFPguidlines2.pdf", "one.pdf");
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Program Files\Adobe\Reader 11.0\Reader\AcroRd32.exe";
            p.StartInfo.Arguments = @"one.pdf";
            p.Start();
        }

        private void Hyperlink_Click_4(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            try
            {
                wc.DownloadFile("https://tribal.nic.in/writereaddata/Schemes/3-A-MJ-MSPtoMFP.pdf", "one.pdf");
                Process p = new Process();
                p.StartInfo.FileName = @"C:\Program Files\Adobe\Reader 11.0\Reader\AcroRd32.exe";
                p.StartInfo.Arguments = @"one.pdf";
                p.Start();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Hyperlink_Click_5(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.DownloadFile("https://tribal.nic.in/writereaddata/Schemes/EquitysupporttoNSTFDC.pdf", "one.pdf");
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Program Files\Adobe\Reader 11.0\Reader\AcroRd32.exe";
            p.StartInfo.Arguments = @"one.pdf";
            p.Start();
        }

        private void Hyperlink_Click_6(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.DownloadFile("https://tribal.nic.in/DivisionsFiles/Education/RevisedGuidelinesFellowshipandScholarship1718.pdf", "one.pdf");
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Program Files\Adobe\Reader 11.0\Reader\AcroRd32.exe";
            p.StartInfo.Arguments = @"one.pdf";
            p.Start();
        }

        private void Hyperlink_Click_7(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.DownloadFile("https://tribal.nic.in/DivisionsFiles/Education/RevisedGuidelinesNOSST1718.pdf", "one.pdf");
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Program Files\Adobe\Reader 11.0\Reader\AcroRd32.exe";
            p.StartInfo.Arguments = @"one.pdf";
            p.Start();
        }

        private void Hyperlink_Click_8(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.DownloadFile("https://tribal.nic.in/writereaddata/Schemes/EDUProformaAnnex2.pdf", "one.pdf");
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Program Files\Adobe\Reader 11.0\Reader\AcroRd32.exe";
            p.StartInfo.Arguments = @"one.pdf";
            p.Start();
        }

        private void Hyperlink_Click_9(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.DownloadFile("https://tribal.nic.in/writereaddata/Schemes/EDUPostMatricScholarshipPMSforSTstudents230513.pdf", "one.pdf");
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Program Files\Adobe\Reader 11.0\Reader\AcroRd32.exe";
            p.StartInfo.Arguments = @"one.pdf";
            p.Start();
        }

        private void Hyperlink_Click_10(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.DownloadFile("https://tribal.nic.in/DivisionsFiles/sg/8scan0004.pdf", "one.pdf");
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Program Files\Adobe\Reader 11.0\Reader\AcroRd32.exe";
            p.StartInfo.Arguments = @"one.pdf";
            p.Start();
        }

        private void Hyperlink_Click_11(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.DownloadFile("https://tribal.nic.in/DivisionsFiles/sg/7Guidelines.pdf", "one.pdf");
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Program Files\Adobe\Reader 11.0\Reader\AcroRd32.exe";
            p.StartInfo.Arguments = @"one.pdf";
            p.Start();
        }

        private void Hyperlink_Click_12(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.DownloadFile("https://tribal.nic.in/DivisionsFiles/sg/EMRSguidlines.pdf", "one.pdf");
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Program Files\Adobe\Reader 11.0\Reader\AcroRd32.exe";
            p.StartInfo.Arguments = @"one.pdf";
            p.Start();
        }

        private void Hyperlink_Click_13(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.DownloadFile("https://tribal.nic.in/writereaddata/Schemes/VTCGuidelines.pdf", "one.pdf");
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Program Files\Adobe\Reader 11.0\Reader\AcroRd32.exe";
            p.StartInfo.Arguments = @"one.pdf";
            p.Start();
        }

        private void Hyperlink_Click_14(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.DownloadFile("https://tribal.nic.in/writereaddata/Schemes/AshramSchoolGuideline.pdf", "one.pdf");
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Program Files\Adobe\Reader 11.0\Reader\AcroRd32.exe";
            p.StartInfo.Arguments = @"one.pdf";
            p.Start();
        }

        private void Hyperlink_Click_15(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.DownloadFile("https://tribal.nic.in/writereaddata/Schemes/CentralySponsorednew.pdf", "one.pdf");
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Program Files\Adobe\Reader 11.0\Reader\AcroRd32.exe";
            p.StartInfo.Arguments = @"one.pdf";
            p.Start();
        }

        private void Hyperlink_Click_16(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.DownloadFile("https://tribal.nic.in/writereaddata/Schemes/VTCGuidelinesAndApplicationFormat.pdf", "one.pdf");
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Program Files\Adobe\Reader 11.0\Reader\AcroRd32.exe";
            p.StartInfo.Arguments = @"one.pdf";
            p.Start();
        }

        private void Hyperlink_Click_17(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.DownloadFile("https://tribal.nic.in/writereaddata/Schemes/NGO-GIAtoVOsGuidelines.pdf", "one.pdf");
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Program Files\Adobe\Reader 11.0\Reader\AcroRd32.exe";
            p.StartInfo.Arguments = @"one.pdf";
            p.Start();
        }

        private void Hyperlink_Click_18(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.DownloadFile("https://tribal.nic.in/writereaddata/Schemes/4-5NGORevisedScheme.pdf", "one.pdf");
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Program Files\Adobe\Reader 11.0\Reader\AcroRd32.exe";
            p.StartInfo.Arguments = @"one.pdf";
            p.Start();
        }

        private void Hyperlink_Click_19(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.DownloadFile("https://tribal.nic.in/writereaddata/Schemes/4-6NGOSchemeStrengthningEducation.pdf", "one.pdf");
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Program Files\Adobe\Reader 11.0\Reader\AcroRd32.exe";
            p.StartInfo.Arguments = @"one.pdf";
            p.Start();

        }

        

        private void Hyperlink_Click_21(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.DownloadFile("https://tribal.nic.in/DivisionsFiles/sg/8scan0004.pdf", "one.pdf");
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Program Files\Adobe\Reader 11.0\Reader\AcroRd32.exe";
            p.StartInfo.Arguments = @"one.pdf";
            p.Start();
        }

        private void Hyperlink_Click_22(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.DownloadFile("https://tribal.nic.in/DivisionsFiles/sg/201606220318460202092Guidelines.pdf", "one.pdf");
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Program Files\Adobe\Reader 11.0\Reader\AcroRd32.exe";
            p.StartInfo.Arguments = @"one.pdf";
            p.Start();
        }

        private void Hyperlink_Click_23(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.DownloadFile("https://tribal.nic.in/DivisionsFiles/sg/subProposalPAC2017-18.pdf", "one.pdf");
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Program Files\Adobe\Reader 11.0\Reader\AcroRd32.exe";
            p.StartInfo.Arguments = @"one.pdf";
            p.Start();

        }


        private void Hyperlink_Click_25(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.DownloadFile("https://tribal.nic.in/DivisionsFiles/sg/DraftBackgroundNoteonconvergence.pdf", "one.pdf");
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Program Files\Adobe\Reader 11.0\Reader\AcroRd32.exe";
            p.StartInfo.Arguments = @"one.pdf";
            p.Start();
        }

        private void Hyperlink_Click_26(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.DownloadFile("https://tribal.nic.in/DivisionsFiles/sg/RevisedGuidelineforsettingupofEKLAVYAMODELRESIDENTIALSCHOOLS.pdf", "one.pdf");
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Program Files\Adobe\Reader 11.0\Reader\AcroRd32.exe";
            p.StartInfo.Arguments = @"one.pdf";
            p.Start();
        }

        private void Page_Initialized(object sender, EventArgs e)
        {


        }

        
        


    }
}
