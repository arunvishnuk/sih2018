﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tribal_FRA_Awareness___Desktop
{
    /// <summary>
    /// Interaction logic for EditProfile.xaml
    /// </summary>
    public partial class EditProfile : Page
    {
        public User user { get; set; }
        public EditProfile()
        {
            InitializeComponent();
        }
        public EditProfile(User u):this()
        {
            this.user = u;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DBConnectivity.Update(user.UserName,email.Text,newpwd.Password);
            this.NavigationService.GoBack();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.NavigationService.GoBack();
        }

       
    }
}
